# vitals
Application for managing vital needs of a man when he comes to a new place
